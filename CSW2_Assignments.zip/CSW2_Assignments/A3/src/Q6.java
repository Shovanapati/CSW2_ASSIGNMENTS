import java.util.Scanner;
import java.util.TreeSet;

public class Q6 {
    public static void main(String[] args) {
        TreeSet<Integer> treeSet = new TreeSet<>();
        Scanner scanner = new Scanner(System.in);

        treeSet.add(10);
        treeSet.add(20);
        treeSet.add(30);
        treeSet.add(40);
        treeSet.add(50);

        System.out.println("TreeSet elements: " + treeSet);

        System.out.print("Enter a number to search: ");
        int num = scanner.nextInt();
        if (treeSet.contains(num)) {
            System.out.println(num + " is present in the TreeSet.");
        } else {
            System.out.println(num + " is not present in the TreeSet.");
        }

        System.out.print("Enter an element to remove: ");
        int removeNum = scanner.nextInt();
        if (treeSet.contains(removeNum)) {
            treeSet.remove(removeNum);
            System.out.println("Element " + removeNum + " removed from TreeSet.");
        } else {
            System.out.println("Element " + removeNum + " not found in the TreeSet.");
        }

        System.out.println("Updated TreeSet elements: " + treeSet);
    }
}
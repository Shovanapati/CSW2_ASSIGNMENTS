import java.util.Scanner;

public class Q5 {
    public static void main(String[] args) {
       final int it=1000;
       String b="hello";
       long start=System.currentTimeMillis();
       StringBuilder sb=new StringBuilder();
       for(int i=0;i<it;i++)
       {
    	   sb.append(b);
    	   
       }
       long end=System.currentTimeMillis();
       System.out.println("time:"+(end-start)+" ms");
    }
}

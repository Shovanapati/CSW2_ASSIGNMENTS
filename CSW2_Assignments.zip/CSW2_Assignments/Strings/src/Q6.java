import java.util.Scanner;

public class Q6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the first string:");
        String firstString = scanner.nextLine();

        System.out.println("Enter the second string:");
        String secondString = scanner.nextLine();

        String firstLower = firstString.toLowerCase();
        String firstUpper = firstString.toUpperCase();
        String secondLower = secondString.toLowerCase();
        String secondUpper = secondString.toUpperCase();

        boolean isEqualIgnoreCase = firstLower.equals(secondLower);

        
        System.out.println("\nComparison (case-insensitive): " + firstLower.equals(firstUpper));

        scanner.close();
    }
}
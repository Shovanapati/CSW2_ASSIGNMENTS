public class Q1 {
    public static void main(String[] args) {
        String str1 = "java";
        String str2 = "java";

        String str3 = new String("java");
        String str4 = new String("java");

        System.out.println("\nString comparison:");
        System.out.println("Comparing str1 and str2: " + (str1 == str2));
        System.out.println("Comparing str1 and str3: " + (str1 == str3));
        System.out.println("Using .equals() method:");
        System.out.println("Comparing str1 and str3: " + str1.equals(str3));
        System.out.println("Comparing str3 and str4: " + str3.equals(str4));
    }
}
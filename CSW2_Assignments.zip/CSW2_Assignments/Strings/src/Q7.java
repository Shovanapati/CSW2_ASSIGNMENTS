
public class Q7 {

}

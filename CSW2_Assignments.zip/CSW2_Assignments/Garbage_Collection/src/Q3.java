public class Q3 {

    private String name;

    public Q3(String name) {
        this.name = name;
    }

    @Override
    protected void finalize() {
        System.out.println("Garbage collected: " + name);
    }

    public static void main(String[] args) {
        Q3 obj = new Q3("Object");

        obj = null;

        System.gc();
    }
}
public class Q7 {
    private String name;
    private int age;
    private String course;

    public Q7(String name, int age, String course) {
        this.name = name;
        this.age = age;
        this.course = course;
    }

    @Override
    protected void finalize() {
        System.out.println("Q7 " + name + " has been successfully garbage collected.");
    }

    public static void main(String[] args) {
        Q7 Q71 = new Q7("man", 20, "CSE");
        Q7 Q72 = new Q7("sho", 22, "csit");

        Runtime runtime = Runtime.getRuntime();
        long totalMemoryBefore = runtime.totalMemory();
        long freeMemoryBefore = runtime.freeMemory();
        System.out.println("Total Memory before: " + totalMemoryBefore);
        System.out.println("Free Memory before: " + freeMemoryBefore);

        Q71 = null;
        Q72 = null;

        System.gc();

        long totalMemoryAfter = runtime.totalMemory();
        long freeMemoryAfter = runtime.freeMemory();
        System.out.println("Total Memory after: " + totalMemoryAfter);
        System.out.println("Free Memory after: " + freeMemoryAfter);
    }
}
public class Q2 {
    private double x;
    private double y;

    Q2(double x, double y) {
        this.x = x;
        this.y = y;
    }

    Q2(Q2 other) {
        this.x = other.getX();
        this.y = other.getY();
    }

    double getX() {
        return x;
    }

    void setX(double x) {
        this.x = x;
    }

    double getY() {
        return y;
    }

    void setY(double y) {
        this.y = y;
    }

    public static void main(String[] args) {
        Q2 point1 = new Q2(3, 4);
        System.out.println("Initial point coordinates ->");
        System.out.println("X: "+point1.getX());
        System.out.println("Y: "+point1.getY());

        Q2 point2 = new Q2(point1);
        System.out.println("Copied point coordinates ->");
        System.out.println("X: "+point2.getX());
        System.out.println("Y: "+point2.getY());

        point1.setX(5);
        point1.setY(6);

        System.out.println("After modification -->");
        System.out.println("Original point coordinates are ->");
        System.out.println("X: "+point1.getX());
        System.out.println("Y: "+point1.getY());
        System.out.println("Copied point coordinates are ->");
        System.out.println("X: "+point2.getX());
        System.out.println("Y: "+point2.getY());
    }
}